import {NexMemory} from './memory/memory.js';
import {NexVideoEngine} from './engines/video-engine.js';
import {NexCodeEngine} from './engines/code-engine.js';
import {NexChatEngine} from './chat-engine.js';
export class NexCore { constructor(options={}){ this.memory=new NexMemory(options.memory); this.video=new NexVideoEngine(); this.code=new NexCodeEngine(); this.chat=new NexChatEngine({memory:this.memory,video:this.video,code:this.code}); }
  train(options={}){ return this.chat.train(options.epochs??120,options.onEpoch); }
  ask(text){ return this.chat.handle(text); }
  saveModel(storageKey='nex-core-model'){ if(typeof localStorage==='undefined') return false; localStorage.setItem(storageKey,this.chat.exportModel()); return true; }
  get status(){ return {name:'NEX Core',version:'0.1.0',offline:true,trainableNetwork:true,videoPlanning:true,videoRendering:false,codeAnalysis:true,generalKnowledge:'limited/local'}; }
}
export {TinyMLP,TextVectorizer} from './neural/tiny-mlp.js';
export {NexMemory} from './memory/memory.js';
export {NexVideoEngine} from './engines/video-engine.js';
export {NexCodeEngine} from './engines/code-engine.js';
