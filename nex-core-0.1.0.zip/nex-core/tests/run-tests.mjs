import assert from 'node:assert/strict';
import {NexCore, TinyMLP, NexMemory, NexVideoEngine, NexCodeEngine} from '../src/index.js';

const core=new NexCore();
const before=JSON.stringify(core.chat.model.toJSON());
const history=core.train({epochs:180});
const after=JSON.stringify(core.chat.model.toJSON());
assert.notEqual(before,after,'os pesos devem mudar durante o treino');
assert.ok(history.at(-1).loss < history[0].loss,'a perda deve diminuir');
assert.ok(history.at(-1).accuracy >= 0.75,'a acurácia final deve ser razoável');

const original=core.chat.model.toJSON();
const restored=TinyMLP.fromJSON(JSON.parse(JSON.stringify(original)));
assert.deepEqual(restored.toJSON(),original,'pesos devem persistir e restaurar');

const mem=new NexMemory(); mem.clear(); mem.remember('meu projeto usa JavaScript');
assert.equal(mem.search('JavaScript').length,1,'memória deve recuperar item relevante');

const video=new NexVideoEngine().plan('crie uma cena 3d noturna com uma nave em movimento e camera pan');
assert.equal(video.schema,'nex.video-plan.v1'); assert.equal(video.scene.objects[0].type,'spaceship'); assert.equal(video.camera.motion,'pan');

const code=new NexCodeEngine().analyze('const x = 1 == 1; console.log(x);');
assert.equal(code.language,'javascript'); assert.ok(code.issues.length>=2,'análise deve detectar padrões');

assert.equal(core.ask('crie uma cena 3d com um robo').type,'video-plan');
assert.equal(core.ask('crie um projeto javascript').type,'code');
assert.equal(core.ask('lembre que meu nome é Ana').type,'memory');

console.log(JSON.stringify({ok:true,epochs:history.length,initialLoss:history[0].loss,finalLoss:history.at(-1).loss,finalAccuracy:history.at(-1).accuracy,weightsChanged:before!==after},null,2));
