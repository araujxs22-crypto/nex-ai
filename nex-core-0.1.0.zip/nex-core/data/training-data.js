export const INTENT_EXAMPLES = [
  {label:'video', text:'crie uma cena 3d com uma nave e camera cinematografica'},
  {label:'video', text:'planeje uma animacao de personagem andando'},
  {label:'video', text:'quero um roteiro visual para um video'},
  {label:'video', text:'monte um ambiente com luz e objetos'},
  {label:'code', text:'crie um projeto javascript'},
  {label:'code', text:'analise este codigo e encontre bugs'},
  {label:'code', text:'preciso de uma funcao em python'},
  {label:'code', text:'estruture os arquivos do aplicativo'},
  {label:'memory', text:'lembre que meu projeto se chama nex'},
  {label:'memory', text:'guarde esta informacao para depois'},
  {label:'memory', text:'o que voce lembra sobre mim'},
  {label:'memory', text:'salve esta preferencia'},
  {label:'general', text:'ola como voce esta'},
  {label:'general', text:'explique o que e inteligencia artificial'},
  {label:'general', text:'qual a diferenca entre treino e memoria'},
  {label:'general', text:'responda uma pergunta comum'}
];
